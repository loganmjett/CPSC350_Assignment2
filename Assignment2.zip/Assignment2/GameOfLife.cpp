#include "GameOfLife.h"
#include <iostream>

/*

GameOfLife::GameOfLife(int r, int c, double pd)
{
  rows = r;
  columns = c;
  popDensity = pd;

}

GameOfLife::GameOfLife(string input)
{
  infile = input;
}

GameOfLife::~GameOfLife()
{
  for (int i = 0; i < rows; ++i)
  {
    delete currentGenArray[i];
    delete nextGenArray[i];

  }
  delete currentGenArray;
  delete nextGenArray;
}

//accessors and mutators
void GameOfLife::SetRows(int rows)
{
  rows = rows;
}
int GameOfLife::GetRows()
{
  return rows;
}
void GameOfLife::SetColumns(int columns)
{
  columns = columns;
}
int GameOfLife::GetColumns()
{
  return columns;
}


void GameOfLife::CreateMap()
{
  cout << "How many rows?" << endl;
  cin >> rows;
  cout << "How many columns?" << endl;
  cin >> columns;
  cout << "What is the Population Density? (Enter a number between 0.0-1.0)" << endl;
  cin >> popDensity;

  //this operation is included to find an integer that will be used to determine how many cells to have a cell start in
  int totalCells = rows * columns;
  double numCells = round(popDensity * totalCells);
  numToFill = static_cast<int>(numCells);

  //assigns each element in the array to a pointer to another array
  currentGenArray = new char*[rows];
  nextGenArray = new char*[rows];
  for (int i = 0; i < rows; ++i)
  {
    currentGenArray[i] = new char[columns];
    nextGenArray[i] = new char[columns];

  }

  RandomFill();


}

//this will take care of a user-input file
void GameOfLife::LoadMap(string input)
{
  //read in from text

  //then

}

//this is used to fill the file
void GameOfLife::RandomFill()
{
  for (int i = 0; i < rows; ++i)
  {
    for (int j = 0; j < columns; ++j)
    {
      currentGenArray[i][j] = '-';
      nextGenArray[i][j] = '-';
    }
  }
  int rowToFill;
  int colToFill;
  for (int k = 0; k < numToFill; ++k)
  {
    rowToFill = rand() % (rows);
    colToFill = rand() % (columns);
    while(!isEmpty(rowToFill, colToFill))
    {
      rowToFill = rand() % (rows);
      colToFill = rand() % (columns);
    }
    currentGenArray[rowToFill][colToFill] = 'X';
  }
}

bool GameOfLife::isEmpty(int r, int c)
{
  bool isEmpty;
  if (currentGenArray[r][c] == '-')
  {
    isEmpty = true;
  }
  else
  {
    isEmpty = false;
  }

  return isEmpty;
}


void GameOfLife::ChooseMode()
{

}

void GameOfLife::OriginalMode()
{
  int numAlive;
  for (int i = 0; i < rows; ++i)
  {
    for (int j = 0; j < columns; ++j)
    {
      if (currentGenArray[i][j] == 'X')
      {
        numAlive += 1;
      }
    }
  }
  while (numAlive > 0)
  {
    int gridAlive = 0;
    for (int i = 0; i < rows; ++i)
    {
      for (int j = 0; j < columns; ++j)
      {
        if (i >= 0 && j-1 >=0)
        {
          if (!isEmpty(i,j-1))
          {
            gridAlive += 1;
          }
        }
        if (i >= 0 && j+1 <=columns)
        {
          if (!isEmpty(i,j+1))
          {
            gridAlive += 1;
          }
        }
        if (i-1 >= 0 && j-1 >=0)
        {
          if (!isEmpty(i-1,j-1))
          {
            gridAlive += 1;
          }
        }
        if (i-1 >= 0 && j >=0)
        {
          if (!isEmpty(i-1,j))
          {
            gridAlive += 1;
          }
        }
        if (i-1 >= 0 && j+1 <=columns)
        {
          if (!isEmpty(i-1,j+1))
          {
            gridAlive += 1;
          }
        }
        if (i+1 <= rows && j-1 >=0)
        {
          if (!isEmpty(i+1,j-1))
          {
            gridAlive += 1;
          }
        }
        if (i+1 <= rows && j >=0)
        {
          if (!isEmpty(i+1,j))
          {
            gridAlive += 1;
          }
        }
        if (i+1 <= rows && j+1 <= columns)
        {
          if (!isEmpty(i+1,j+1))
          {
            gridAlive += 1;
          }
        }

        if (gridAlive <= 1)
        {
          nextGenArray[i][j] = '-';
        }
        if (gridAlive == 2)
        {
          nextGenArray[i][j] = nextGenArray[i][j];
        }
        else
        {
          nextGenArray[i][j] = 'X';
        }
        //should be an update here to copy currentGenArray to nextGenArray
      }
  }

}

void GameOfLife::DonutMode()
{
  //incomplete
}

void GameOfLife::MirrorMode()
{
  //incomplete
}

void GameOfLife::toFile()
{
  //incomplete
}

void GameOfLife::fromFile()
{
  //incomplete
}

void GameOfLife::Pause()
{
  //incomplete
}

void GameOfLife::Play()
{
  ifstream inFS;
  string response;
  string file;
  cout << "Would you like to choose a map? (y/n)" << endl;
  cin >> response;
  if (response.compare("y") == 0)
  {
    cout << "Enter a filename... (filename.txt)" << endl;
    cin >> file;
    inFS.open(file);
    while (!inFS.is_open())
    {
      cout << "Could not open file: " << file << endl << "Please try again." << endl;
      cin >> file;
      inFS.open(file);
    }
    inFS.close();
    //GameOfLife(file);
  }
  else
  {
    cout << "No file given. Creating Map..." << endl;
  }
}

*/
