#ifndef GameOfLife_h
#define GameOfLife_h
#include <iostream>
#include <fstream>
#include <math.h>
#include <string>
using namespace std;

class GameOfLife
{
  public:
    //constructors

    //constructor with an int representing row, an int for column, and a double for population density
    GameOfLife(int r, int c, double pd);
    //constructor with a string input that will serve as the map given by user
    GameOfLife(string input);
    //destructor, will destruct the double pointers nextGenArray and currentGenArray, as well as their elements
    ~GameOfLife();

    //helper functions

    //creates a random map
    void CreateMap();
    //loads the map given by user, takes the file given as a string input
    void LoadMap(string input);
    //prompts user for one of three modes, original, donut, and mirror, the necessary mode to be played
    void ChooseMode();
    //original mode of the Game of Life. This mode will only interact within the given array with no special conditions
    void OriginalMode();
    //donut mode takes the top/bottom rows and left-/right-most columns and wraps them around to the other side (e.g. row 1 = row 9 if there are 8 total rows)
    void DonutMode();
    //mirror mode takes the top/bottom rows and left-/right columns and mirrors them directly next to themselves (e.g. row 9 = row 8 if there are 8 total rows)
    void MirrorMode();
    //checks to see if the map, or in this case, array is empty for a given row r and column c
    bool isEmpty(int r, int c);
    //reads through the file to get layout and nothing more
    void fromFile();
    //will output the results to a new file
    void toFile();
    //pauses the game at the users request
    void Pause();
    //begins the game by prompting for a file if desired, or dimnesions if desired, and then creates game objects
    void Play();
    //responsible for completely filling the randomized grid by selecting a random row and column, and then checking to make sure it is empty, this is only used for grid setup
    void RandomFill();


    //these double pointers will act as an array of pointers (rows) pointing to arrays (columns)

    //this array holds what the next generation should be according to the previous
    char **nextGenArray;
    //this array holds the current generation that will be used to produce the next generation
    char **currentGenArray;

    //rows of the grid
    int rows;
    //columns of the grid
    int columns;
    //population density (should be a number between 0 and 1)
    double popDensity;
    //this is the number of grid spaces to be filled upon creation given rows, columns, and population density
    int numToFill;
    //this variable will hold the file passed in by the user
    string infile; //make sure to deal with incorrect files, as well as create a method to get rows/cols when none are provided

    //accessors and mutators
    void SetRows(int rows);
    int GetRows();
    void SetColumns(int columns);
    int GetColumns();


  private:
    //no private variables included

};

#endif
