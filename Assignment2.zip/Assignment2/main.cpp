#include "GameOfLife.cpp"

int main(int argc, char **argv)
{
  cout << "***THIS PROGRAM IS INCOMPLETE***" << endl;
  cout << "- Please look at comments provided throughout each of the files, as well as the README in order to see thought process." << endl;
  cout << "- My source file, GameOfLife.cpp, is completely commented out with in order to preserve runability of this code." << endl;
  cout << "- GameOfLife.h contains comments indicating what the purpose of each method/variable should/would be if code was functional." << endl;
  return 0;
}
